function abc()
{
    var x=document.getElementById("t1").value;
    y=(x-32)*5/9;
    document.getElementById("t2").value=y;
    
}
function xyz()
{
    var x=document.getElementById("t2").value;
    y=(x*9/5)+32;
    document.getElementById("t1").value=y;
    
}
function pqr()
{
    document.getElementById("t1").value=clearInterval;
     document.getElementById("t2").value=clearInterval;
    
}